# Handoff: TVMaze ORM Results UI

## Overview
A small web frontend for the existing Django project (TVMaze → PostgreSQL ORM optimisation). Three pages, for presenting the project to viva examiners:
1. **Results** (`/`): benchmark results from `results/benchmark_results.csv` and `results/query_plans.txt`.
2. **Shows** (`/shows/`): browse shows with their network, filter by status / network / name.
3. **Explainer** (`/explainer/`): step through the N+1 loop and watch SQL queries pile up (optional, needs a little plain JavaScript).

## About the Design Files
`ORM Optimisation App.dc.html` is a **design reference built in HTML**, not production code. Open it in a browser to see the look and behaviour (`support.js` must sit next to it). Recreate it as **plain Django templates + one static CSS file**, following the rules in `instructions.txt`: no React, no JS framework, simplest possible code. Do not copy the HTML file into the Django app.

## Fidelity
High-fidelity. Match colours, type, spacing and copy below. Use the **Lab** theme (the default). Editorial and Terminal themes exist in the reference but are not needed.

## Data rules
- All numbers come from real files. **Read them at request time; never hardcode new values.**
  - `results/benchmark_results.csv`: experiments A–F2 (queries, avg_seconds, pg_planning_ms, pg_execution_ms, notes).
  - `results/query_plans.txt`: the four EXPLAIN ANALYZE plans (split on blank lines; first line of each block is the title).
- Shows page reads the database: `Show.objects.select_related("network").order_by("tvmaze_id")`. All 485 shows, not a sample. Paginate at 50 if needed.
- Derived values (compute in the view, simple Python):
  - speed-up = slow avg / fast avg (A/B ≈ 21×, C/D ≈ 1.4×, E1/E2 PG exec ≈ 38×, E1/E2 Python ≈ 2.6×)
  - time per query = avg ms / queries (A ≈ 0.39 ms, C ≈ 1.5 ms)
  - bar width % = value / max(value pair) × 100, min width 3px
- Plan details shown in cards (buffers, rows removed, cost) can be parsed from `query_plans.txt` with simple string searches (`"Buffers: shared hit="`, `"Rows Removed by Filter:"`, `"cost=0.00.."`). E2 has no "Rows Removed" line → show 0. If parsing feels too complex, hardcoding these four plan values is acceptable as they come from the saved file.

## Design Tokens (Lab theme)
| Token | Value |
|---|---|
| bg | `#f5f5f3` |
| surface (cards, header) | `#ffffff` |
| ink (text) | `#18191b` |
| muted text | `#5d6066` |
| line (borders) | `#e2e2de` |
| soft (bar track, hover, selected row) | `#efefec` |
| code background | `#f0f0ed` |
| accent (primary button, links) | `oklch(0.52 0.14 255)` ≈ `#2f63c4` |
| good (optimised) | `oklch(0.55 0.13 160)` ≈ `#13895f` |
| bad (naive / N+1) | `oklch(0.58 0.15 35)` ≈ `#c8553a` |
| radius | 8px everywhere |
| Font (UI) | `"Helvetica Neue", Helvetica, Arial, sans-serif` |
| Font (mono) | `"JetBrains Mono", ui-monospace, monospace` (Google Fonts, 400/500/600) |
| Heading weight | 600 |

Type scale: page H1 40px/1.1 (34px on Shows/Explainer), letter-spacing −0.02em · section H2 24px · card H3 20px · big stat 40px (index cards 30px) · body 15px/1.5 · secondary 13–14px · labels 12px uppercase, letter-spacing 0.06em, muted · mono values 12.5–13px.

Spacing: page max-width 1200px, padding 44px 28px 80px · sections gap 48px · card padding 26px, internal gap 20–22px · card grid `repeat(auto-fit, minmax(min(100%,440px),1fr))`, gap 20px. No shadows.

## Screens

### Shared header
Sticky, white, 1px bottom border, min-height 60px, inner max-width 1200px.
Left: "TVMaze ORM Lab" (17px, 600) + "Django 5.2 · PostgreSQL 18" (mono 12px muted). Then nav links: Results · Shows · Explainer (14px, 500, padding 0 14px, full header height; active = ink text + 2px ink bottom border; inactive = muted). Right: "485 shows · 81 networks · 61,658 episodes" (mono 12px muted, from `Model.objects.count()`).

### 1. Results
- **Intro**: H1 "Django ORM and database optimisation"; muted paragraph: "Measured results from benchmark_queries. Each experiment ran 10 times after one unmeasured warm-up run, on a Windows laptop with PostgreSQL 18 on localhost."
- **Section "The N+1 query problem"**: two cards.
  - Eyebrow (mono 12px muted): "Experiments A → B · ForeignKey" / "Experiments C → D · reverse ForeignKey". Title: "Shows → network" / "Shows → episodes". Top-right outline button "Replay in explainer" → `/explainer/?rel=network` or `?rel=episodes`.
  - Two big stats: "457 → 1" / "SQL queries" and "21×" (good colour) / "faster · 179.7 → 8.4 ms avg".
  - Bars: label "QUERIES" then two rows; label "AVG TIME PER RUN" then two rows. Row = grid `22px | 1fr | 72px`: letter (mono muted), 10px track (soft) with fill (bad for slow, good for fast), value right-aligned mono.
  - Two code chips (code bg, mono 12.5px, padding 8px 12px): `A  Show.objects.order_by("id")`, `B  Show.objects.select_related("network").order_by("id")` (letter in bad/good colour).
  - Per-query strip (top border, 16px padding-top): "≈ 0.39 ms per query" (22px) / "in A · 179.7 ms ÷ 457 queries, the fixed cost of each round-trip".
  - Footnote (13px muted): A/B "29 shows have no network, so Django skips the lookup for them: 1 + 456 = 457 queries." C/D "Both versions still build 61,658 Episode objects in Python, which is why the time drops less than the query count."
- **Section "Indexing"** (subtitle "before and after migration 0002 · EXPLAIN ANALYZE"): two cards.
  - E card: eyebrow "Experiments E1 → E2 · episode_airdate_idx", title "Episodes aired in March 2015", sub "501 of 61,658 rows match · selective filter". Plan chips: `Seq Scan` → `Bitmap Index Scan` (good border + text). Stats: 38× PostgreSQL execution · 2.6× Python avg time · 704 kB index size. Metric grid (4 cells, 1px line gaps): Buffers read 658 → 133 pages; Rows removed by filter 61,157 → 0; Planner cost estimate 1582.87 → 666.89; Planning time 0.076 → 0.090 ms (sub: execution 8.504 → 0.223 ms). Bars for PG execution and Python avg. Button "Show EXPLAIN ANALYZE" toggles the two raw plans in `<pre>` blocks (code bg, mono 11.5px, horizontal scroll).
  - F card: same structure. Title "Shows with status = 'Ended'", sub "442 of 485 rows match · low-selectivity filter". Chips `Seq Scan` → `Seq Scan` + "index not used" (bad colour). Stats: 91% of rows match · 7 buffers read, both runs · 16 kB index size. Metric grid: 7 → 7, 43 → 43, 13.06 → 13.06, 0.064 → 0.077 ms. Bars use muted fill (no winner).
  - Use `<details><summary>` for the plan toggle; no JS needed.
- **Section "All measurements"** (subtitle mono "results/benchmark_results.csv"): white bordered table, horizontally scrollable, min-width 940px. Columns: Experiment · Dataset · Queries · Avg / run · PG exec · Planning · Est. cost · Plan. Numbers mono 12.5px right-aligned; empty = "–" muted. N+1 query counts coloured bad/good.

### 2. Shows
- H1 "Shows", muted line "485 shows from TVMaze show pages 0–1."
- Right of title: a box "SQL queries to render this list" with the real count, measured in the view with `CaptureQueriesContext` (should be 1 with select_related). Optional `?load=naive` to show the N+1 count, as the design's toggle does.
- Filter row: search input (GET `q`, `name__icontains`), status buttons All / Ended / Running (GET `status`; selected = ink bg, bg-coloured text), network `<select>` (GET `network`). Right: "N of 485" mono muted.
- Table (white card): columns ID (44px, mono muted) · Name (500) · Network + country (country mono 11.5px muted) · Type · Status (mono 12px; Running = good, others muted). Row padding 11px 18px, 1px bottom border, hover soft. Clicking a row → `?show=<id>` highlights it (soft bg) and fills the side panel.
- Side panel (sticky top 84px, max-width 420px): mono "tvmaze_id N", H2 name, field grid (show_type, language, status, network · country), an "ORM" code block, and an "Episodes" list from `show.episodes.order_by("season","number")` (season, number, name, airdate). Empty state: "Select a show to see its fields."

### 3. Explainer (optional)
Two segmented controls: [Show → network | Show → episodes] and [Naive (N+1) | select_related / prefetch_related]. Left: the real loop code from `benchmark_queries.py` with line numbers; the active line gets soft bg + 3px left border (bad when a per-show query fires, accent otherwise) and a one-line explanation below. Below that: big counter "count / total" (totals A 457, B 1, C 486, D 2), progress bar, buttons Step · Play/Pause (accent) · Reset. When finished: "Measured avg per run" + the other version's summary. Right: SQL log, newest first, last 10 entries, "… N earlier queries". Play speeds up as it goes (adds `max(1, round(count×0.06))` every 60ms). One small static `explainer.js` with plain DOM code is enough; see the logic class in the reference file for the exact SQL strings and notes.

## Files
- `ORM Optimisation App.dc.html`: the design reference (open in a browser with `support.js` beside it).
- Suggested Django files: `shows/views.py` (3 views), `shows/templates/shows/base.html`, `results.html`, `shows.html`, `explainer.html`, `shows/static/shows/style.css`, optional `explainer.js`, routes in `config/urls.py`.
